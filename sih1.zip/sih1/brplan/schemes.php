<!doctype html>
<html lang="en">



<head>

    <!--====== Required meta tags ======-->
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!--====== Title ======-->
    <title>Rural Plans</title>

    <!--====== Favicon Icon ======-->
    <link rel="shortcut icon" href="assets/images/favicon.ico" type="image/png">

    <!--====== Bootstrap css ======-->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">

    <!--====== Fontawesome css ======-->
    <link rel="stylesheet" href="assets/css/all.css">

    <!--====== flaticon css ======-->
    <link rel="stylesheet" href="assets/css/flaticon.css">

    <!--====== Line Icons css ======-->
    <link rel="stylesheet" href="assets/css/LineIcons.html">

    <!--====== animate css ======-->
    <link rel="stylesheet" href="assets/css/animate.min.css">

    <!--====== Magnific Popup css ======-->
    <link rel="stylesheet" href="assets/css/magnific-popup.css">

    <!--====== Slick css ======-->
    <link rel="stylesheet" href="assets/css/slick.css">

    <!--====== Default css ======-->
    <link rel="stylesheet" href="assets/css/default.css">

    <!--====== Style css ======-->
    <link rel="stylesheet" href="assets/css/style.css">


</head>

<body>


    
   

    
    <div class="search-overlay">
        <div class="d-table">
            <div class="d-table-cell">
                <div class="search-overlay-layer"></div>
                <div class="search-overlay-layer"></div>
                <div class="search-overlay-layer"></div>
                
                
                <div class="search-overlay-close">
                    <span class="search-overlay-close-line"></span>
                    <span class="search-overlay-close-line"></span>
                </div>

                <div class="search-overlay-form">
                    <form>
                        <input type="text" class="input-search" placeholder="Search here...">
                        <button type="submit"><i class='far fa-search'></i></button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <div class="sidebar-modal">  
        <div class="modal right fade" id="myModal2" tabindex="-1" role="dialog" aria-labelledby="myModalLabel2">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">
                                <i class="far fa-times"></i>
                            </span>
                        </button>
                        <h2 class="modal-title" id="myModalLabel2">
                            <a href="">
                                <img src="logo.png" alt="Logo">
                            </a>
                        </h2>
                    </div>
                    <div class="modal-body">
                        <div class="sidebar-modal-widget">
                            <h3 class="title">About Us</h3>
                            <p>BR PLAN is a team to help rural people to avail the facilities </p>
                        </div>
                        <div class="sidebar-modal-widget">
                            
                            </ul>
                        </div>
                        <div class="sidebar-modal-widget">
                            <h3 class="title">Contact Info</h3>
                            <ul class="contact-info">
                                <li>
                                    <i class="far fa-map-marker-alt"></i>
                                    Address
                                    <span>DBIT,Bangalore,Karnataka</span>
                                </li>
                                <li>
                                    <i class="far fa-envelope"></i>
                                    Email
                                    <span>brplan@gmail.com</span>
                                </li>
                                <li>
                                    <i class="far fa-phone"></i>
                                    Phone
                                    <span>+91 7483493052</span>
                                </li>
                            </ul>
                        </div>
                        <div class="sidebar-modal-widget">
                            <h3 class="title">Connect With Us</h3>
                            <ul class="social-list">
                                <li>
                                    <a href="#">
                                        <i class='fab fa-facebook-f'></i>
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        <i class='fab fa-twitter'></i>
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        <i class='fab fa-instagram'></i>
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        <i class='fab fa-google-plus-g'></i>
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        <i class='fab fa-linkedin-in'></i>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

  
    <header class="header-area">
        <div class="header-top">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="header-top-content d-flex justify-content-center  justify-content-sm-between align-items-center">
                            <div class="header-top-text d-none d-lg-block">
                                <p><i class="far fa-leaf"></i> A platform for applying Rural Schemes</p>
                            </div>
                            <div class="header-top-btns d-flex align-items-center text-lg-right text-center">
                                <ul>
                                    <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                                    <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                                    <li><a href="#"><i class="fab fa-instagram"></i></a></li>
                                    <li><a href="#"><i class="fab fa-google-plus-g"></i></a></li>
                                </ul>
                                <a class="d-none d-sm-block" href="">singup <i class="far fa-plus"></i></a>
                            </div>
                            <div id="google_translate_element"></div>
	


	<script type="text/javascript">
		function googleTranslateElementInit() {
			new google.translate.TranslateElement(
				{pageLanguage: 'ka'},
				'google_translate_element'
			);
		}
	</script>
<script type="text/javascript" src=
"https://translate.google.com/translate_a/element.js?
		cb=googleTranslateElementInit">
	</script>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="header-info">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="header-info-item">
                            <div class="logo">
                                <a href="#"><img src="logo.png" alt="logo"></a>
                            </div>
                            <div class="header-info d-lg-flex d-none">
                                <div class="item">
                                    <i class="fal fa-phone"></i>
                                    <span>Phone Number</span>
                                    <a href="tel:+91 7483493052">
                                        <h5 class="title">+91 7483493052</h5>
                                    </a>
                                </div>
                                <div class="item">
                                    <i class="fal fa-envelope-open"></i>
                                    <span>Email Address</span>
                                    <a href="mailto:anishahkandachar@gmail.com">
                                        <h5 class="title">brplan@gmail.com</h5>
                                    </a>

                                </div>
                            </div>
                            <div class="header-flag">
                                <ul class="flag-wrap">
                                    <li class="flag-item-top">
                                        
                                        <a href="#" class="flag-bar d-flex align-items-center">
                                           
                                            <span>Eng <i class="far fa-angle-down"></i></span>
                                        </a>
                                        <ul class="flag-item-bottom">
                                            <li class="flag-item">
                                                <a href="#" class="flag-link">
                                                    <img src="hindi.jpg" alt="Image">
                                                    Hindi 
                                                </a>
                                            </li>
                                            <li class="flag-item">
                                                <a href="#" class="flag-link">
                                                    <img src="karn.jpg" alt="Image">
                                                    Kannada
                                                </a>
                                            </li>
                                            <li class="flag-item">
                                                <a href="#" class="flag-link">
                                                    <img src="tamil.jpg" alt="Image">
                                                    Tamil
                                                </a>
                                            </li>
                                            <li class="flag-item">
                                                <a href="#" class="flag-link">
                                                    <img src="andra.png" alt="Image">
                                                    Telugu
                                                </a>
                                            </li>
                                            <li class="flag-item">
                                                <a href="#" class="flag-link">
                                                    <img src="mahrastra.jpg" alt="Image">
                                                    Malyalam
                                                </a>
                                            </li>
                                            <li class="flag-item">
                                                <a href="#" class="flag-link">
                                                    <img src="gujurat.png" alt="Image">
                                                    Gujurati
                                                </a>
                                            </li>
                                        </ul>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="header-menu">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="navigation ">
                            <nav class="navbar navbar-expand-lg">
                                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarFive" aria-controls="navbarFive" aria-expanded="false" aria-label="Toggle navigation">
                                    <span class="toggler-icon"></span>
                                    <span class="toggler-icon"></span>
                                    <span class="toggler-icon"></span>
                                </button> 
                                <div class="collapse navbar-collapse sub-menu-bar" id="navbarFive">
                                    <ul class="navbar-nav mr-auto">
                                        
                                        <li class="nav-item">
                                            <a class="page-scroll" href="">About Us</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="page-scroll" href="">Team</a>
                                            <ul>
                                                
                                            </ul>
                                        </li>
                                        <li class="nav-item">
                                            
                                            <div class="nav-item dropdown">
                                                <a href="#">Schemes</a>
                                               
                                            </div>

                                            <style>
                                                .dropdown:hover .dropdown-menu{
                                                    display: block;
                                                }
                                                .dropdown-menu{
                                                    margin-top: 0;
                                                }
                                            </style>
                                            <script>
                                                $(document).ready(function(){
                                                    $(".dropdown").hover(function(){
                                                        var dropdownMenu = $(this).children(".dropdown-menu");
                                                        if(dropdownMenu.is(":visible")){
                                                            dropdownMenu.parent().toggleClass("open");
                                                        }
                                                    });
                                                });     
                                                </script>



                                            





                                        </li>
                                        <li class="nav-item">
                                            
                                        </li>
                                        <li class="nav-item">
                                           
                                        </li>
                                        
                                    </ul>
                                </div>
                                <div class="navbar-btns">
                                    <ul>
                                        <li><a class="search-box" href="#"><i class="fal fa-search"></i></a></li>
                                        <li><a class="d-none d-lg-inline" href="#myModal2" data-toggle="modal"><i class="fal fa-bars"></i></a></li>
                                    </ul>
                                </div>
                            </nav> 
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>
<br>
<div class="container">

<table class="table">
  <thead>
    <tr>
      
      <th scope="col">SCHEME NAME</th>
      
      <th scope="col">APPLY</th>
    </tr>
  </thead>
  <tbody>



<h2><center>Rural Schemes by Central Government</center></h2>
<br>

<?php


include_once "conn.php";
$sql="SELECT * FROM schemes";
$res=mysqli_query($conn,$sql);
while($row=mysqli_fetch_array($res)){


    







?>



  


    <tr>
      
      <td><?php
      
      
      echo $row["name"];
      ?>
      </td>
      <td><a href="viewscheme.php?id=<?php echo $row["id"]?>"><input type="button" value="Apply" class="btn btn-success"></td>
    </tr>
    <?php

}
  ?>
    </tr>
  </tbody>
</table>

<br>


<h2>Rural schemes by State government</h2>


<form action="stateschemes.php" method="post">

<div class="form-group">
                      <label for="country">State/union Territory</label>
                      <select class="form-control" id="country-dropdown" name="state">
                      <option value="">Select state</option>
                        <?php
                        require_once "mydbCon.php";

                        $result = mysqli_query($conn,"SELECT * FROM countries");

                        while($row = mysqli_fetch_array($result)) {
                        ?>
                            <option  value="<?php echo $row['id'];?>"><?php echo $row["name"]; ?></option>
                        <?php
                        }
                        ?>
                        
                      </select>
                    </div>
                    <input type="submit">

</form>












 <!--====== jquery js ======-->
 <script src="assets/js/vendor/modernizr-3.6.0.min.js"></script>
    <script src="assets/js/vendor/jquery-1.12.4.min.js"></script>

    <!--====== Bootstrap js ======-->
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/popper.min.js"></script>

    <!--====== Slick js ======-->
    <script src="assets/js/slick.min.js"></script>

    <!--====== Isotope js ======-->
    <script src="assets/js/isotope.pkgd.min.js"></script>

    <!--====== Images Loaded js ======-->
    <script src="assets/js/imagesloaded.pkgd.min.js"></script>

    <!--====== counterup js ======-->
    <script src="assets/js/jquery.counterup.min.js"></script>

    <!--====== waypoints js ======-->
    <script src="assets/js/waypoints.min.js"></script>

    <!--====== Magnific Popup js ======-->
    <script src="assets/js/jquery.magnific-popup.min.js"></script>

    <!--====== Ajax Contact js ======-->
    <script src="assets/js/ajax-contact.html"></script>

    <!--====== Main js ======-->
    <script src="assets/js/main.js"></script>

</body>


<!-- Mirrored from themeforest.kreativdev.com/sosso/ by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 24 Jul 2022 12:22:50 GMT -->
</html>
