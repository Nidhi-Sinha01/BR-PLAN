<?php
$email=$_POST["email"];
$password=$_POST["password"];
include_once "conn.php";



$sql = "SELECT * FROM admin";
$res=mysqli_query($conn,$sql);
while($row=mysqli_fetch_assoc($res)){
if($email==$row["email"] && $password==$row["password"]){
    header("location: admin/dist");
}
else{
$flag=1;
}
}

// If result matched $myusername and $mypassword, table row must be 1 row
  



if($flag==1){

    ?>

<script>

alert("invalid login");
window.location.href = 'index.html';

</script>
<?php
}
?>