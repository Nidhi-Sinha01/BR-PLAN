<div class="form-group">
    <form action="" method="post">
                      <label for="country">State/union Territory</label>
                      <select class="form-control" id="country-dropdown" name="state">
                      <option value="">Select state</option>
                        <?php
                        require_once "mydbCon.php";

                        $result = mysqli_query($conn,"SELECT * FROM countries");

                        while($row = mysqli_fetch_array($result)) {
                        ?>
                            <option  value="<?php echo $row['id'];?>"><?php echo $row["name"]; ?></option>
                        <?php
                        }
                        ?>
                        
                      </select>
                    </div>
















<input type="submit" value="submit" class="btn btn-primary" name="submit1">

                    </form>

                    <?php
                    require_once "conn.php";
if(isset($_POST["submit1"])){
    
$statecode=$_POST["state"];
echo $statecode;
$query="SELECT * FROM `stateschemes` ";
$result=mysqli_query($conn,$query);
while($row1=mysqli_fetch_assoc($result)){
    echo $row1["name"];
}

}
?>

