-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 22, 2022 at 04:01 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.0.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `my_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `cities`
--

CREATE TABLE `cities` (
  `id` int(11) NOT NULL,
  `state_id` int(11) NOT NULL,
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '1=Active | 0=Inactive'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cities`
--

INSERT INTO `cities` (`id`, `state_id`, `name`, `status`) VALUES
(1, 2, 'Anekal', 1),
(5, 37, 'Car Nicobar', 1),
(6, 37, 'Great Nicobar', 1),
(7, 37, 'Nancowry', 1),
(8, 38, 'Diglipur', 1),
(9, 38, 'Mayabunder', 1),
(10, 38, 'Rangat', 1),
(11, 39, 'Ferrargunj', 1),
(12, 39, 'Little Andaman', 1),
(13, 39, 'Port Blair', 1),
(24, 24, 'Channapatna', 1),
(25, 24, 'Kanakpura', 1),
(27, 24, 'Magadi', 1),
(28, 24, 'Harohalli', 1),
(29, 24, 'Ramanagara', 1);

-- --------------------------------------------------------

--
-- Table structure for table `countries`
--

CREATE TABLE `countries` (
  `id` int(11) NOT NULL,
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '1=Active | 0=Inactive'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `countries`
--

INSERT INTO `countries` (`id`, `name`, `status`) VALUES
(1, 'Andhra Pradesh', 1),
(2, 'Arunachal Pradesh', 1),
(3, 'Assam', 1),
(4, 'Bihar', 1),
(5, 'Chhattisgarh', 1),
(6, 'Goa', 1),
(7, 'Gujarat', 1),
(8, 'Haryana', 1),
(9, 'Himachal Pradesh', 1),
(10, 'Jharkhand', 1),
(11, 'Karnataka', 1),
(12, 'Kerala', 1),
(14, 'Maharashtra', 1),
(15, 'Manipur', 1),
(16, 'Meghalaya', 1),
(17, 'Mizoram', 1),
(18, 'Nagaland', 1),
(19, 'Odisha', 1),
(20, 'Punjab', 1),
(21, 'Rajasthan', 1),
(22, 'Sikkim', 1),
(23, 'Tamil Nadu', 1),
(24, 'Telangana', 1),
(25, 'Tripura', 1),
(26, 'Uttar Pradesh', 1),
(27, 'Uttarakhand', 1),
(28, 'West Bengal', 1),
(29, 'ANDAMAN AND NICOBAR ', 1),
(35, 'Madhya Pradesh', 1);

-- --------------------------------------------------------

--
-- Table structure for table `states`
--

CREATE TABLE `states` (
  `id` int(11) NOT NULL,
  `country_id` int(11) NOT NULL,
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '1=Active | 0=Inactive'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `states`
--

INSERT INTO `states` (`id`, `country_id`, `name`, `status`) VALUES
(1, 11, 'BAGALKOTE', 1),
(2, 11, 'BALLARI', 1),
(3, 11, 'BELAGAVI', 1),
(4, 11, 'BENGALURU RURAL', 1),
(5, 11, 'BENGALURU URBAN', 1),
(6, 11, 'BIDAR', 1),
(7, 11, 'CHAMARAJANAGARA', 1),
(8, 11, 'CHIKKABALLAPURA', 1),
(9, 11, 'CHIKKAMAGALURU', 1),
(10, 11, 'CHITRADURGA', 1),
(11, 11, 'DAKSHINA KANNADA', 1),
(12, 11, 'DAVANGERE', 1),
(13, 11, 'DHARWAD', 1),
(14, 11, 'GADAG', 1),
(15, 11, 'HASSAN', 1),
(16, 11, 'HAVERI', 1),
(17, 11, 'KALABURAGI', 1),
(18, 11, 'KODAGU', 1),
(19, 11, 'KOLAR', 1),
(20, 11, 'KOPPAL', 1),
(21, 11, 'MANDYA', 1),
(22, 11, 'MYSURU', 1),
(23, 11, 'RAICHUR', 1),
(24, 11, 'RAMANAGARA', 1),
(25, 11, 'SHIVAMOGGA', 1),
(31, 11, 'TUMAKURU', 1),
(32, 11, 'UDUPI', 1),
(33, 11, 'UTTARA KANNADA', 1),
(34, 11, 'VIJAYANAGAR', 1),
(35, 11, 'VIJAYAPURA', 1),
(36, 11, 'YADGIR', 1),
(37, 29, 'NICOBARS', 1),
(38, 29, 'NORTH AND MIDDLE ANDAMAN', 1),
(39, 29, 'SOUTH ANDAMANS', 1),
(42, 1, 'Anantapur', 1),
(43, 1, 'Chittoor', 1),
(44, 1, '	East Godavari', 1),
(45, 1, 'Guntur', 1),
(46, 1, 'Krishna', 1),
(47, 1, 'Kurnool', 1),
(48, 1, 'Prakasam', 1),
(49, 1, 'Sri Potti Sriramulu (Nellore)', 1),
(50, 1, 'Srikakulam', 1),
(51, 1, 'Visakhapatnam', 1),
(52, 1, 'Vizianagaram', 1),
(53, 1, 'West Godavari', 1),
(54, 1, 'YSR', 1),
(55, 2, 'Anjaw', 1),
(56, 2, 'Changlang', 1),
(57, 2, 'East Kameng', 1),
(58, 2, 'Pasighat', 1),
(59, 2, 'Lohit', 1),
(60, 2, 'Lower Subansiri', 1),
(61, 2, 'Papum Pare', 1),
(62, 2, 'Tawang Town', 1),
(63, 2, 'Tirap', 1),
(64, 2, 'Lower Dibang Valley', 1),
(65, 2, 'Upper Siang', 1),
(66, 2, 'Upper Subansiri', 1),
(67, 2, 'West Kameng', 1),
(68, 2, 'West Siang', 1),
(69, 2, 'Upper Dibang Valley', 1),
(70, 2, 'Kurung Kumey', 1),
(71, 3, 'Baksa', 1),
(72, 3, 'Barpeta', 1),
(73, 3, 'Bongaigaon', 1),
(74, 3, 'Cachar', 1),
(75, 3, 'Chirang', 1),
(76, 3, 'Darrang', 1),
(77, 3, 'Dhemaji', 1),
(78, 3, 'Dhubri', 1),
(79, 3, 'Dibrugarh', 1),
(80, 3, '	Dima Hasao', 1),
(81, 3, 'Goalpara', 1),
(82, 3, 'Golaghat', 1),
(83, 3, 'Hailakandi', 1),
(84, 3, 'Jorhat', 1),
(85, 3, 'Kamrup', 1),
(86, 3, 'Kamrup Metropolitan', 1),
(87, 3, 'Karbi Anglong', 1),
(88, 3, 'Karimganj', 1),
(89, 3, 'Kokrajhar', 1),
(90, 3, 'Lakhimpur', 1),
(91, 3, 'Morigaon', 1),
(92, 3, 'Nagaon', 1),
(93, 3, 'Nalbari', 1),
(94, 3, 'Sivasagar', 1),
(95, 3, 'Sonitpur', 1),
(96, 3, 'Tinsukia', 1),
(97, 3, 'Udalguri', 1),
(98, 3, 'Biswanath', 1),
(99, 3, 'Charaideo', 1),
(100, 3, '	Hojai', 1),
(101, 3, 'Majuli', 1),
(102, 3, 'South Salamara-Mankachar', 1),
(103, 3, 'West Karbi Anglong', 1),
(104, 4, 'Araria', 1),
(105, 4, 'Arwal', 1),
(106, 4, 'Aurangabad', 1),
(107, 4, 'Banka', 1),
(108, 4, 'Begusarai', 1),
(109, 4, 'Bhagalpur', 1),
(110, 4, 'Bhojpur', 1),
(111, 4, 'Buxar', 1),
(112, 4, 'Darbhanga', 1),
(113, 4, '	Gaya', 1),
(114, 4, '	Gopalganj', 1),
(115, 4, 'Jamui', 1),
(116, 4, 'Jehanabad', 1),
(117, 4, 'Kaimur', 1),
(118, 4, 'Katihar', 1),
(119, 4, '	Khagaria', 1),
(120, 4, '	Kishanganj', 1),
(121, 4, '	Lakhisarai', 1),
(122, 4, 'Madhepura', 1),
(123, 4, 'Madhubani', 1),
(124, 4, 'Munger', 1),
(125, 4, 'Muzaffarpur', 1),
(126, 4, 'Nalanda', 1),
(127, 4, 'Nawada', 1),
(128, 4, 'Pashchim Champaran', 1),
(129, 4, 'Patna', 1),
(130, 4, 'Purbi Champaran	', 1),
(131, 4, '	Purnia', 1),
(132, 4, 'Rohtas', 1),
(133, 4, 'Saharsa', 1),
(134, 4, 'Samastipur', 1),
(135, 4, 'Saran', 1),
(136, 4, 'Sheikhpura', 1),
(137, 4, 'Sheohar', 1),
(138, 4, 'Sitamarhi', 1),
(139, 4, '	Siwan', 1),
(140, 4, '	Supaul', 1),
(141, 4, '	Vaishali', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cities`
--
ALTER TABLE `cities`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `countries`
--
ALTER TABLE `countries`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `states`
--
ALTER TABLE `states`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cities`
--
ALTER TABLE `cities`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `countries`
--
ALTER TABLE `countries`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT for table `states`
--
ALTER TABLE `states`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=142;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
