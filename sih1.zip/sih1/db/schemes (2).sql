-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 22, 2022 at 04:01 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.0.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `brplan`
--

-- --------------------------------------------------------

--
-- Table structure for table `schemes`
--

CREATE TABLE `schemes` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `provider` text NOT NULL,
  `image` text NOT NULL,
  `meta` text NOT NULL,
  `about` text NOT NULL,
  `doc1` varchar(200) NOT NULL,
  `doc2` varchar(200) NOT NULL,
  `doc3` varchar(200) NOT NULL,
  `doc4` varchar(200) NOT NULL,
  `uploder` varchar(200) NOT NULL,
  `upload_ip` varchar(200) NOT NULL,
  `upload_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `schemes`
--

INSERT INTO `schemes` (`id`, `name`, `provider`, `image`, `meta`, `about`, `doc1`, `doc2`, `doc3`, `doc4`, `uploder`, `upload_ip`, `upload_date`) VALUES
(28, 'MNREGA', 'MINISTRY OF LABOUR', 'mnrega.jpg', 'MNREGA,LABOUR,RURAL,RURAL SCHEMES,WAGE,JOB CARD,', 'Finance Minister Nirmala Sitharaman on March 26th, 2020, the workers under the MGNREGA would get a hike of Rs. 2000 each on an average. It was also announced that three crore senior citizens, persons with disabilities, and widows will get a one-time additional amount of Rs 1,000 in two installments which will be provided through DBT (Direct Benefit Transfer) over three months. This announcement was made as an initiative towards the loss caused by the Covid-19 outbreak. The 21 days lockdown was expected to cost the Indian Economy a cost of around 9 lakh crores.  Funds worth Rs 31,000 crore are also to be provided to augment medical testing, screening, and providing better healthcare facilities to those who have been affected financially due to the Covid-19 outbreak.\r\n<br>\r\n<br>\r\n<h2>Objectives</h2>\r\n</h5>\r\nThe Mahatma Gandhi National Rural Employment Guarantee Act (MGNREGA) has the following objectives:\r\n<br>\r\n', 'ADRESS PROOF', 'JOB CARD', '', '', 'admin', '', '2022-08-18 19:47:24');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `schemes`
--
ALTER TABLE `schemes`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `schemes`
--
ALTER TABLE `schemes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
