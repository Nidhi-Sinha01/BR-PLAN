<?php
$fname=$_POST["fname"];
$lname=$_POST["lname"];
$address=$_POST["address"];
$aadharnum=$_POST["aadharnum"];
$phone=$_POST["phone"];
$gender=$_POST["sex"];
$pincode=$_POST["pincode"];
$village=$_POST["village"];









$hName='localhost'; // host name

    $uName='root';   // database user name

    $password='';   // database password

    $dbName = "my_db"; // database name

    $conn= mysqli_connect($hName,$uName,$password,"$dbName");





$statecode=$_POST["state"];
$districtcode=$_POST["district"];
$talukcode=$_POST['taluka'];


$sql="SELECT name FROM countries WHERE id='$statecode'";
$res=mysqli_query($conn,$sql);
while($row=mysqli_fetch_array($res)){
$state=$row["name"];

}




$sql1="SELECT name FROM states WHERE id='$districtcode'";
$res1=mysqli_query($conn,$sql1);
while($row1=mysqli_fetch_array($res1)){
$district=$row1["name"];

}


$sql3="SELECT name FROM cities WHERE id='$talukcode'";
$res3=mysqli_query($conn,$sql3);
while($row3=mysqli_fetch_array($res3)){
$taluka=$row3["name"];

}


$statey = substr($state, 0, 3);
$appln1=strtoupper($statey);
















?>











<?php 
    // Database connection
    include("conn.php");
    
        // Set image placement folder
        $target_dir = "img_dir/";
        // Get file path
        $target_file = $target_dir . basename($_FILES["fileUpload1"]["name"]);
        // Get file extension
        $imageExt = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
        // Allowed file types
        $allowd_file_ext = array("jpg", "jpeg", "png");
        
        if (!file_exists($_FILES["fileUpload1"]["tmp_name"])) {
           $resMessage = array(
               "status" => "alert-danger",
               "message" => "Select image to upload."
           );
        } else if (!in_array($imageExt, $allowd_file_ext)) {
            $resMessage = array(
                "status" => "alert-danger",
                "message" => "Allowed file formats .jpg, .jpeg and .png."
            );            
        } else if ($_FILES["fileUpload1"]["size"] > 2097152) {
            $resMessage = array(
                "status" => "alert-danger",
                "message" => "File is too large. File size should be less than 2 megabytes."
            );
        } else if (file_exists($target_file)) {
            $resMessage = array(
                "status" => "alert-danger",
                "message" => "File already exists."
            );
        } {
                $resMessage = array(
                    "status" => "alert-danger",
                    "message" => "Image coudn't be uploaded."
                );
            }
        
  
        












        $target_dir = "img_dir/";
        // Get file path
        $target_file1= $target_dir . basename($_FILES["fileUpload2"]["name"]);
        // Get file extension
        $imageExt = strtolower(pathinfo($target_file1, PATHINFO_EXTENSION));
        // Allowed file types
        $allowd_file_ext = array("jpg", "jpeg", "png");
        
        if (!file_exists($_FILES["fileUpload2"]["tmp_name"])) {
           $resMessage = array(
               "status" => "alert-danger",
               "message" => "Select image to upload."
           );
        } else if (!in_array($imageExt, $allowd_file_ext)) {
            $resMessage = array(
                "status" => "alert-danger",
                "message" => "Allowed file formats .jpg, .jpeg and .png."
            );            
        } else if ($_FILES["fileUpload2"]["size"] > 2097152) {
            $resMessage = array(
                "status" => "alert-danger",
                "message" => "File is too large. File size should be less than 2 megabytes."
            );
        } else if (file_exists($target_file1)) {
            $resMessage = array(
                "status" => "alert-danger",
                "message" => "File already exists."
            );
        } else {
                $resMessage = array(
                    "status" => "alert-danger",
                    "message" => "Image coudn't be uploaded."
                );
            }
        




$appln=$appln1.rand(0,10000000000);
echo $appln;


$query="INSERT INTO mnrega(application_num,firstname,lastname,address,aadharnum,phone,gender,state,district,taluk,pincode,village,doc1,doc2,statecode,districtcode,talukcode) VALUES('$appln','$fname','$lname','$address','$aadharnum','$phone','$gender','$state','$district','$taluka','$pincode','$village','$target_file','$target_file1','$statecode','$districtcode','$talukcode')";
$result=mysqli_query($conn,$query);















        




  if($res){


?>
<script>

alert("your application  number is:<?php echo $appln;  ?>")
<?php





?>
</script>


<?php



 

}      
?>